-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 06, 2018 at 09:53 AM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `peternakan`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `user_id` int(50) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`user_id`, `nama`, `email`, `password`) VALUES
(2, 'Febi Aris Rinaldi', 'rfebiaris@gmail.com', '330b8d964c0b81954959fae0e1b31b56');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_agen`
--

CREATE TABLE `tbl_agen` (
  `id_agen` int(50) NOT NULL,
  `kode_agen` varchar(50) NOT NULL,
  `nama_agen` varchar(50) NOT NULL,
  `alamat_agen` text NOT NULL,
  `telepon_agen` varchar(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_agen`
--

INSERT INTO `tbl_agen` (`id_agen`, `kode_agen`, `nama_agen`, `alamat_agen`, `telepon_agen`) VALUES
(1, '001', 'Febi Aris Rinaldi', 'Kp. Selamanjah Desa Tamanjaya Kecamatan Ciemas Kabupaten Sukabumi', '085772672543'),
(2, '002', 'M. Anjas Muslim', 'Sukaraja', '085746353426'),
(3, '09283938', 'Abu', 'd', '3'),
(4, '3', '1', '', ''),
(5, '1', '1', '1', '2'),
(6, '2', 'ww', 'w', ''),
(7, '33', 'e', 'r', '3'),
(8, '2', '2', '2', '2'),
(9, '1', '11', '1', '1'),
(10, '9', '9', '9', '9'),
(11, '2', '5', '5', '0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_distribusi`
--

CREATE TABLE `tbl_distribusi` (
  `id_distribusi` int(50) NOT NULL,
  `kode_distribusi` varchar(50) NOT NULL,
  `tgl_distribusi` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `harga_satuan` int(50) NOT NULL,
  `id_agen` int(50) NOT NULL,
  `jumlah` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_distribusi`
--

INSERT INTO `tbl_distribusi` (`id_distribusi`, `kode_distribusi`, `tgl_distribusi`, `harga_satuan`, `id_agen`, `jumlah`) VALUES
(10, '005', '2018-09-20 17:00:00', 5000, 1, '500.00'),
(11, '001', '2018-09-18 17:00:00', 5422, 1, '400.00'),
(12, '001', '2018-07-31 17:00:00', 4500, 3, '10.00'),
(13, '001', '2018-07-31 17:00:00', 4500, 3, '10.00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pegawai`
--

CREATE TABLE `tbl_pegawai` (
  `id_pegawai` int(50) NOT NULL,
  `nama_pegawai` varchar(50) NOT NULL,
  `alamat` text NOT NULL,
  `telepon` varchar(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_pegawai`
--

INSERT INTO `tbl_pegawai` (`id_pegawai`, `nama_pegawai`, `alamat`, `telepon`) VALUES
(1, 'Febi Aris Rinaldi', 'Jampang', '09777767678'),
(2, 'Anjas', 'Sukaraja', '08793837245');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pengeluaran`
--

CREATE TABLE `tbl_pengeluaran` (
  `id_pengeluaran` int(50) NOT NULL,
  `nama_pengeluaran` varchar(255) NOT NULL,
  `tgl_pengeluaran` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `jml_pengeluaran` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_pengeluaran`
--

INSERT INTO `tbl_pengeluaran` (`id_pengeluaran`, `nama_pengeluaran`, `tgl_pengeluaran`, `jml_pengeluaran`) VALUES
(6, 'Sapi sakit', '2018-09-30 17:00:00', 400000),
(7, 'Sapi sakit', '2018-09-17 17:00:00', 2000000),
(8, 'Sapi Geuring', '2018-09-17 17:00:00', 2000000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sapi`
--

CREATE TABLE `tbl_sapi` (
  `id_sapi` int(50) NOT NULL,
  `berat_sapi` int(50) NOT NULL,
  `berat_terakhir` int(50) NOT NULL,
  `deskripsi` text NOT NULL,
  `identitas` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_sapi`
--

INSERT INTO `tbl_sapi` (`id_sapi`, `berat_sapi`, `berat_terakhir`, `deskripsi`, `identitas`) VALUES
(1, 400000, 400000, 'Sapi betina belum mengandung anak', 'Sapi01'),
(2, 400000, 400000, 'Sapi yang baru melahirkan 2 anak sehingga susu berkuran karena menyusia anaknya', 'Sapi02'),
(3, 400000, 400000, 'Sapi betina belum mengandung anak', 'sapi03'),
(4, 400000, 400000, 'Sapi betina belum mengandung anak', 'sapi04'),
(5, 400000, 400000, 'Sapi betina belum mengandung anak', 'sapi05'),
(6, 400000, 400000, 'Sapi betina belum mengandung anak', 'sapi06'),
(7, 400000, 400000, 'Sapi betina belum mengandung anak', 'sapi07'),
(8, 400000, 400000, 'Sapi betina belum mengandung anak', 'sapi08'),
(9, 400000, 400000, 'Sapi betina belum mengandung anak', 'sapi09'),
(10, 400000, 400000, 'Sapi betina belum mengandung anak', 'sapi10');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_susu`
--

CREATE TABLE `tbl_susu` (
  `id_susu` int(50) NOT NULL,
  `tgl_perah` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `jumlah_liter` int(50) NOT NULL,
  `id_sapi` int(50) NOT NULL,
  `id_pegawai` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_susu`
--

INSERT INTO `tbl_susu` (`id_susu`, `tgl_perah`, `jumlah_liter`, `id_sapi`, `id_pegawai`) VALUES
(1, '2018-09-17 17:00:00', 5000, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tokens`
--

CREATE TABLE `tokens` (
  `id` int(11) NOT NULL,
  `token` varchar(255) NOT NULL,
  `user_id` int(10) NOT NULL,
  `created` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tokens`
--

INSERT INTO `tokens` (`id`, `token`, `user_id`, `created`) VALUES
(1, '1331617e67d52070abb58e6b44c8b6', 1, '2018-10-12');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `tbl_agen`
--
ALTER TABLE `tbl_agen`
  ADD PRIMARY KEY (`id_agen`);

--
-- Indexes for table `tbl_distribusi`
--
ALTER TABLE `tbl_distribusi`
  ADD PRIMARY KEY (`id_distribusi`);

--
-- Indexes for table `tbl_pegawai`
--
ALTER TABLE `tbl_pegawai`
  ADD PRIMARY KEY (`id_pegawai`);

--
-- Indexes for table `tbl_pengeluaran`
--
ALTER TABLE `tbl_pengeluaran`
  ADD PRIMARY KEY (`id_pengeluaran`);

--
-- Indexes for table `tbl_sapi`
--
ALTER TABLE `tbl_sapi`
  ADD PRIMARY KEY (`id_sapi`);

--
-- Indexes for table `tbl_susu`
--
ALTER TABLE `tbl_susu`
  ADD PRIMARY KEY (`id_susu`);

--
-- Indexes for table `tokens`
--
ALTER TABLE `tokens`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `user_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tbl_agen`
--
ALTER TABLE `tbl_agen`
  MODIFY `id_agen` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `tbl_distribusi`
--
ALTER TABLE `tbl_distribusi`
  MODIFY `id_distribusi` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `tbl_pegawai`
--
ALTER TABLE `tbl_pegawai`
  MODIFY `id_pegawai` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tbl_pengeluaran`
--
ALTER TABLE `tbl_pengeluaran`
  MODIFY `id_pengeluaran` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `tbl_sapi`
--
ALTER TABLE `tbl_sapi`
  MODIFY `id_sapi` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `tbl_susu`
--
ALTER TABLE `tbl_susu`
  MODIFY `id_susu` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tokens`
--
ALTER TABLE `tokens`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
