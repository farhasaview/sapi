<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

  public $aktif='welcome';

  public function __construct() {
    parent::__construct();

    $this->isLogin();
    
    $this->clearCache();
    $this->load->model('Model_sapi');
    $this->load->model('Model_agen');
    $this->load->model('Model_pegawai');
    $this->load->model('Model_susu');
    $this->load->model('Model_pengeluaran');
    $this->load->model('Model_distribusi');
    $this->load->helper('nominal');
  }
	 private function isLogin() {
    $isLogin = $this->session->userdata('logged_in');
    if ($isLogin != 'yes') {
    $msg = array('failed' => 'Login failed');
    $this->session->set_flashdata('msg', $msg['failed']);
      redirect(base_url('login'));
    }
  }

  private function clearCache() {
    $this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
    $this->output->set_header("Pragma: no-cache");
  }
  public function index()
	{
    $data['aktif'] = $this->aktif;

    $data['sapi'] = $this->Model_sapi->all();
    $data['agen'] = $this->Model_agen->all();
    $data['pegawai'] = $this->Model_pegawai->all();
    $data['susu'] = $this->Model_susu->total_liter();
    $data['pengeluaran'] = $this->Model_pengeluaran->total_pengeluaran();
    $data['distribusi'] = $this->Model_distribusi->total_distribusi();
		$data['content']='admin/dashboard';
		$this->load->view('admin/template/body', $data);
	}
}
