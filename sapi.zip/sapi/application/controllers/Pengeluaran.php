<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pengeluaran extends CI_Controller {

  public $aktif='pengeluaran';

	public function __construct() {
	parent::__construct();

      $this->isLogin();
      $this->clearCache();

        $this->load->model('Model_pengeluaran');
        
  	}
    private function isLogin() {
    $isLogin = $this->session->userdata('logged_in');
    if ($isLogin != 'yes') {
    $msg = array('failed' => 'Login failed');
    $this->session->set_flashdata('msg', $msg['failed']);
      redirect(base_url('login'));
    }
  }

  private function clearCache() {
    $this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
    $this->output->set_header("Pragma: no-cache");
  }

	public function index()
	{
    $data['aktif'] = $this->aktif;

		$data['all']=$this->Model_pengeluaran->all();
		$data['content']='admin/pengeluaran/list';
		$this->load->view('admin/template/body', $data);
	}

	public function add()
	{
		$data['pengeluaran'] = array(
	      'id_pengeluaran' => '',
	      'nama_pengeluaran' => '',
	      'tgl_pengeluaran' => '',
        'jml_pengeluaran' => ''
	    );

    $data['aktif'] = $this->aktif;
    $data['title'] = "Add Pengeluaran";
		$data['content']='admin/pengeluaran/form';
		$this->load->view('admin/template/body', $data);
	}

	public function edit($id){
    $pengeluaran = $this->Model_pengeluaran->find($id);
    $data['pengeluaran'] = array(
      'id_pengeluaran' => $pengeluaran->id_pengeluaran,
      'nama_pengeluaran' => $pengeluaran->nama_pengeluaran,
      'tgl_pengeluaran' => $pengeluaran->tgl_pengeluaran,
      'jml_pengeluaran' => $pengeluaran->jml_pengeluaran
    );
    
    $data['aktif'] = $this->aktif;
    $data['title'] = "Edit Pengeluaran";
    $data['content'] = 'admin/pengeluaran/form';
    $this->load->view('admin/template/body', $data);
  	}

	public function save() {
    $param = $this->input->post();
    if ($param['id_pengeluaran'] == "") {
      $result = $this->Model_pengeluaran->add($param);
    } else {
      $result = $this->Model_pengeluaran->edit($param);
    }

    $msg = array('success' => 'Data saved successfully');
    $this->session->set_flashdata('msg', $msg['success']);

    redirect(base_url('pengeluaran'));
  }

  public function delete($id) {
    $this->Model_pengeluaran->delete($id);
    redirect(base_url('pengeluaran'));
  }
}
