<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Agen extends CI_Controller {

  public $aktif='agen';

	public function __construct() {
	parent::__construct();

      $this->isLogin();
      $this->clearCache();

        $this->load->model('Model_agen');
  	}
     private function isLogin() {
    $isLogin = $this->session->userdata('logged_in');
    if ($isLogin != 'yes') {
    $msg = array('failed' => 'Login failed');
    $this->session->set_flashdata('msg', $msg['failed']);
      redirect(base_url('login'));
    }
  }

  private function clearCache() {
    $this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
    $this->output->set_header("Pragma: no-cache");
  }

	public function index()
	{
    $data['aktif'] = $this->aktif;
		$data['all']=$this->Model_agen->all();
		$data['content']='admin/agen/list';
		$this->load->view('admin/template/body', $data);
	}

	public function add()
	{
		$data['agen'] = array(
	      'id_agen' => '',
	      'kode_agen' => '',
	      'nama_agen' => '',
        'alamat_agen' => '',
        'telepon_agen' => ''
	    );

    $data['aktif'] = $this->aktif;
    $data['title'] = "Add Agen";
		$data['content']='admin/agen/form';
		$this->load->view('admin/template/body', $data);
	}

	public function edit($id){
    $agen = $this->Model_agen->find($id);
    $data['agen'] = array(
      'id_agen' => $agen->id_agen,
      'kode_agen' => $agen->kode_agen,
      'nama_agen' => $agen->nama_agen,
      'alamat_agen' => $agen->alamat_agen,
      'telepon_agen' => $agen->telepon_agen
    );
    $data['aktif'] = $this->aktif;
    $data['title'] = "Edit Agen";
    $data['content'] = 'admin/agen/form';
    $this->load->view('admin/template/body', $data);
  	}

	public function save() {
    $param = $this->input->post();
    if ($param['id_agen'] == "") {
      $result = $this->Model_agen->add($param);
    } else {
      $result = $this->Model_agen->edit($param);
    }

    $msg = array('success' => 'Data saved successfully');
    $this->session->set_flashdata('msg', $msg['success']);

    redirect(base_url('agen'));
  }

  public function delete($id) {
    $this->Model_agen->delete($id);
    redirect(base_url('agen'));
  }

}
