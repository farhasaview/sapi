<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 
class Report extends CI_Controller {
 	public function __construct() {
	parent::__construct();

	$this->isLogin();
	$this->clearCache();
      
        $this->load->model('Model_sapi');
        $this->load->model('Model_agen');
        $this->load->model('Model_distribusi');
        $this->load->model('Model_pegawai');
        $this->load->model('Model_pengeluaran');
        $this->load->model('Model_susu');
        $this->load->library('PdfGenerator');
  	}
  private function isLogin() {
    $isLogin = $this->session->userdata('logged_in');
    if ($isLogin != 'yes') {
    $msg = array('failed' => 'Login failed');
    $this->session->set_flashdata('msg', $msg['failed']);
      redirect(base_url('login'));
    }
  }

  private function clearCache() {
    $this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
    $this->output->set_header("Pragma: no-cache");
  }
	public function sapi()
	{ 
		$data['all']=$this->Model_sapi->all();
	    $html = $this->load->view('table_report', $data, true);
	    
	    $this->pdfgenerator->generate($html,'data_sapi','portrait');
	}

	public function agen()
	{
		$data['all']=$this->Model_agen->all();
	    $html = $this->load->view('report_agen', $data, true);
	    
	    $this->pdfgenerator->generate($html,'data_agen','portrait');
	}

	public function distribusi($date1,$date2)
	{

		$this->db->select('a.tgl_distribusi, b.nama_agen, a.kode_distribusi, a.harga_satuan, a.jumlah');
    	$this->db->from('tbl_distribusi as a');
    	$this->db->join('tbl_agen as b','a.id_agen=b.id_agen');
    	if ($date1!='0000-00-00' && $date2!='0000-00-00') {
    		# code...
      	$this->db->where('tgl_distribusi >', $date1);
      	$this->db->where('tgl_distribusi <', $date2);
    	}
		
		$query=$this->db->get();
    	$data['all']=$query->result_array();

	    $html = $this->load->view('report_distribusi', $data, true);
	    
	    $this->pdfgenerator->generate($html,'data_distribusi','portrait');

	}

	public function pegawai()
	{
		$data['all']=$this->Model_pegawai->all();
	    $html = $this->load->view('report_pegawai', $data, true);
	    
	    $this->pdfgenerator->generate($html,'data_pegawai', 'portrait');
	}

	public function pengeluaran()
	{
		$data['all']=$this->Model_pengeluaran->all();
	    $html = $this->load->view('report_pengeluaran', $data, true);
	    
	    $this->pdfgenerator->generate($html,'data_pengeluaran','portrait');
	}

	public function susu()
	{
		$data['all']=$this->Model_susu->all();
	    $html = $this->load->view('report_susu', $data, true);
	    
	    $this->pdfgenerator->generate($html,'data_susu','portrait');
	}

	public function distribusiall()
	{
		$data['all']=$this->Model_distribusi->all();
	    $html = $this->load->view('report_distribusi2', $data, true);
	    
	    $this->pdfgenerator->generate($html,'data_distribusi','portrait');
	}
}