<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sapi extends CI_Controller {

  public $aktif='sapi';

	public function __construct() {
	parent::__construct();

  $this->isLogin();
  $this->clearCache();
      
        $this->load->model('Model_sapi');   
  	}
  private function isLogin() {
    $isLogin = $this->session->userdata('logged_in');
    if ($isLogin != 'yes') {
    $msg = array('failed' => 'Login failed');
    $this->session->set_flashdata('msg', $msg['failed']);
      redirect(base_url('login'));
    }
  }
  private function clearCache() {
    $this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
    $this->output->set_header("Pragma: no-cache");
  }

	public function index()
	{
    $data['aktif'] = $this->aktif;

		$data['all']=$this->Model_sapi->all();
		$data['content']='admin/sapi/list';
		$this->load->view('admin/template/body', $data);
	}

	public function add()
	{
		$data['sapi'] = array(
	      'id_sapi' => '',
        'identitas' => '',
	      'berat_sapi' => '',
	      'berat_terakhir' => '',
        'deskripsi' => ''
	    );

    $data['aktif'] = $this->aktif;
    $data['title'] = "Add data sapi";
		$data['content']='admin/sapi/form';
		$this->load->view('admin/template/body', $data);
	}

	public function edit($id){
    $sapi = $this->Model_sapi->find($id);
    $data['sapi'] = array(
      'id_sapi' => $sapi->id_sapi,
      'identitas' => $sapi->identitas,
      'berat_sapi' => $sapi->berat_sapi,
      'berat_terakhir' => $sapi->berat_terakhir,
      'deskripsi' => $sapi->deskripsi
    );
    $data['aktif'] = $this->aktif;
    $data['title'] = "Edit data sapi";
    $data['content'] = 'admin/sapi/form';
    $this->load->view('admin/template/body', $data);
  	}

	public function save() {
    $param = $this->input->post();
    if ($param['id_sapi'] == "") {
      $result = $this->Model_sapi->add($param);
    } else {
      $result = $this->Model_sapi->edit($param);
    }

    $msg = array('success' => 'Data saved successfully');
    $this->session->set_flashdata('msg', $msg['success']);

    redirect(base_url('sapi'));
  }

  public function delete($id) {
    $this->Model_sapi->delete($id);
    redirect(base_url('sapi'));
  }
	
}
