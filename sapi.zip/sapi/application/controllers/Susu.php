<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Susu extends CI_Controller {

  public $aktif='susu';

	public function __construct() {
	parent::__construct();

      $this->isLogin();
      $this->clearCache();
      
        $this->load->model('Model_susu');
        $this->load->model('Model_sapi');
        $this->load->model('Model_pegawai');
  	}
  private function isLogin() {
    $isLogin = $this->session->userdata('logged_in');
    if ($isLogin != 'yes') {
    $msg = array('failed' => 'Login failed');
    $this->session->set_flashdata('msg', $msg['failed']);
      redirect(base_url('login'));
    }
  }

  private function clearCache() {
    $this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
    $this->output->set_header("Pragma: no-cache");
  }

	public function index()
	{
    $data['aktif'] = $this->aktif;

		$data['all']=$this->Model_susu->all();
		$data['content']='admin/susu/list_susu';
		$this->load->view('admin/template/body', $data);
	}

	public function add()
	{
    // mengambil data sapi dan pegawai untuk relasi ke susu
    $data['sapi']=$this->Model_sapi->all();
    $data['pegawai']=$this->Model_pegawai->all();
		$data['susu'] = array(
	      'id_susu' => '',
	      'tgl_perah' => '',
	      'jumlah_liter' => '',
        'id_sapi' => '',
        'id_pegawai' => ''
	    );
    $data['aktif'] = $this->aktif;
    $data['title'] = "Add Susu";
		$data['content']='admin/susu/form_susu';
		$this->load->view('admin/template/body', $data);
	}

	public function edit($id){
    $data['sapi']=$this->Model_sapi->all();
    $data['pegawai']=$this->Model_pegawai->all();
    $susu = $this->Model_susu->find($id);
    $data['susu'] = array(
      'id_susu' => $susu->id_susu,
      'tgl_perah' => date('Y-m-d', strtotime($susu->tgl_perah)),
      'jumlah_liter' => $susu->jumlah_liter,
      'id_sapi' => $susu->id_sapi,
      'id_pegawai' => $susu->id_pegawai
    );
    $data['aktif'] = $this->aktif;
    $data['title'] = "Edit Susu";
    $data['content'] = 'admin/susu/form_susu';
    $this->load->view('admin/template/body', $data);
  	}

	public function save() {
    $param = $this->input->post();

    if ($param['id_susu'] == "") {
      $result = $this->Model_susu->add($param);
    } else {
      $result = $this->Model_susu->edit($param);
    }

    $msg = array('success' => 'Data saved successfully');
    $this->session->set_flashdata('msg', $msg['success']);

    redirect(base_url('susu'));
  }

  public function delete($id) {
    $this->Model_susu->delete($id);
    redirect(base_url('susu'));
  }

}
