<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Distribusi extends CI_Controller {

  public $aktif='distribusi';

	public function __construct() {
	parent::__construct();

      $this->isLogin();
      $this->clearCache();

        $this->load->model('Model_distribusi');
        $this->load->model('Model_agen');
  	}
    private function isLogin() {
    $isLogin = $this->session->userdata('logged_in');
    if ($isLogin != 'yes') {
    $msg = array('failed' => 'Login failed');
    $this->session->set_flashdata('msg', $msg['failed']);
      redirect(base_url('login'));
    }
  }

  private function clearCache() {
    $this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
    $this->output->set_header("Pragma: no-cache");
  }
  
	public function index()
	{
    $data['aktif'] = $this->aktif;
		$data['all']=$this->Model_distribusi->all();
		$data['content']='admin/distribusi/list';
		$this->load->view('admin/template/body', $data);
	}

	public function add()
	{
    //mengambil data agen untuk relasi ke distribusi
    $data['agen'] = $this->Model_agen->all();
		$data['distribusi'] = array(
	      'id_distribusi' => '',
	      'kode_distribusi' => '',
	      'tgl_distribusi' => '',
	      'harga_satuan' => '',
        'id_agen' => '',
        'jumlah' => ''
	    );
    $data['aktif'] = $this->aktif;
    $data['title'] = "Add Distribusi";
		$data['content']='admin/distribusi/form';
		$this->load->view('admin/template/body', $data);
	}

	public function edit($id){
    $data['agen'] = $this->Model_agen->all();
    $distribusi = $this->Model_distribusi->find($id);
    $data['distribusi'] = array(
      'id_distribusi' => $distribusi->id_distribusi,
      'kode_distribusi' => $distribusi->kode_distribusi,
      'tgl_distribusi' => date('Y-m-d', strtotime($distribusi->tgl_distribusi)),
      'harga_satuan' => $distribusi->harga_satuan,
      'id_agen' => $distribusi->id_agen,
      'jumlah' => $distribusi->jumlah
    );
    $data['aktif'] = $this->aktif;
    $data['title'] = "Edit Distribusi";
    $data['content'] = 'admin/distribusi/form';
    $this->load->view('admin/template/body', $data);
  	}

	public function save() {
    $param = $this->input->post();
    if ($param['id_distribusi'] == "") {
      $result = $this->Model_distribusi->add($param);
    } else {
      $result = $this->Model_distribusi->edit($param);
    }

    $msg = array('success' => 'Data saved successfully');
    $this->session->set_flashdata('msg', $msg['success']);

    redirect(base_url('distribusi'));
  }

  public function delete($id) {
    $this->Model_distribusi->delete($id);
    redirect(base_url('distribusi'));
  }

  public function reportdistribusi()
  {
    $data['aktif'] = $this->aktif;
    $this->db->select('a.tgl_distribusi, b.nama_agen, a.kode_distribusi, a.harga_satuan, a.jumlah');
    $this->db->from('tbl_distribusi as a');
    $this->db->join('tbl_agen as b','a.id_agen=b.id_agen');
    if ($this->input->post('btn') == 'submit') {
      $this->db->where('tgl_distribusi >=', $this->input->post('date1'));
      $this->db->where('tgl_distribusi <=', $this->input->post('date2'));
      if ($this->form_validation->run() === TRUE)
     {
        $data['date1']=$this->input->post('date1');
        $data['date2']=$this->input->post('date2');
     }
    }elseif ($this->input->post('btn') == 'print') {
      $date1=$this->input->post('date1')== '' ? '0000-00-00' : $this->input->post('date1');
      $date2=$this->input->post('date2')== '' ? '0000-00-00' : $this->input->post('date2');
       redirect($this->config->item('backend_folder').'report/distribusi/'.$date1.'/'.$date2);
    }elseif ($this->input->post('btn') == 'printall') {
       redirect(base_url('report/distribusiall'));
    }
    $query=$this->db->get();
    $data['all']=$query->result_array();


    $data['content']='admin/distribusi/list2';
    $this->load->view('admin/template/body', $data);
  }

}