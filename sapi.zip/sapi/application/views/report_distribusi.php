<!DOCTYPE html>
<html>
<head>
  <title>Report Table</title>
  <style type="text/css">
  #outtable{
    padding: 20px;
    border:1px solid #e3e3e3;
    width:100%;
    border-radius: 5px;
  }
  
  /*  .short{
      width: 50px;
    }
 
    .normal{
      width: 150px;
      }*/
      
      table{
        border-collapse: collapse;
        font-family: arial;
        color:#5E5B5C;
      }
      
      thead th{
        text-align: left;
        padding: 10px;
      }
      
      tbody td{
        border-top: 1px solid #e3e3e3;
        padding: 10px;
      }
      
      tbody tr:nth-child(even){
        background: #F6F5FA;
      }
      
      tbody tr:hover{
        background: #EAE9F5
      }
    </style>
    <style>
    img {
      position: absolute;
      left: 0px;
      top: 0px;
      z-index: -1;
    }
  </style>
</head>
<body>
  <img src="./assets/images/icon/l.png" width="100" height="140">
  <h1 align="center"> Peternakan Sapi Perah <br>Mudrikah</h1>
  <h4 align="center"> Kp. Nyangkokot, Gang Ledeng, RT 06 RW 03, Desa Karawang, Selabintana </h4>
  <hr />
  <div id="outtable">
    Dicetak Pada : <?php $tgl=date('d-M-Y');
    echo $tgl;?>
    <h4 align="center"><u>Laporan Data Distribusi</u></h4>
    <table>
      <thead>
        <tr>
          <th class="short">No.</th>
          <th class="normal">Tanggal Distribusi</th>
          <th class="normal">Agen Distributor</th>
          <th class="normal">Kode Distribusi</th>
          <th class="normal">Harga Satuan</th>
          <th class="normal">Jumlah</th>
          <th class="normal">Total</th>
        </tr>
      </thead>
      <tbody>
        <?php $no=1;
        foreach ($all as $data) { ?>
          <tr>
            <td><?= $no++ ?></td>
            <td><?= $data['tgl_distribusi'] ?></td>
            <td><?= $data['nama_agen'] ?></td>
            <td><?= $data['kode_distribusi'] ?></td>
            <td><?= $data['harga_satuan'] ?></td>
            <td><?= $data['jumlah'] ?></td>
            <td><?= $data['jumlah'] * $data['harga_satuan'] ?></td>
          </tr>
        <?php } ?>
      </tbody>
    </table>
  </div>
</body>
</html>