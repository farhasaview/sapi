<!DOCTYPE html>
<html>
<head>
  <title>Report Table</title>
  <style type="text/css">
  #outtable{
    padding: 20px;
    border:1px solid #e3e3e3;
    width:100%;
    border-radius: 5px;
  }
  
 /*   .short{
      width: 50px;
      }*/
      
      .normal{
        width: 150px;
      }
      
      table{
        border-collapse: collapse;
        font-family: arial;
        color:#5E5B5C;
      }
      
      thead th{
        text-align: left;
        padding: 10px;
      }
      
      tbody td{
        border-top: 1px solid #e3e3e3;
        padding: 10px;
      }
      
      tbody tr:nth-child(even){
        background: #F6F5FA;
      }
      
      tbody tr:hover{
        background: #EAE9F5
      }
    </style>
    <style>
    img {
      position: absolute;
      left: 0px;
      top: 0px;
      z-index: -1;
    }
  </style>
</head>
<body>
  <img src="./assets/images/icon/l.png" width="100" height="140">
  <h1 align="center"> Peternakan Sapi Perah <br>Mudrikah</h1>
  <h4 align="center"> Kp. Nyangkokot, Gang Ledeng, RT 06 RW 03, Desa Karawang, Selabintana </h4>
  <hr />
  <div id="outtable">
    Dicetak Pada : <?php $tgl=date('d-M-Y');
    echo $tgl;?>
    <h4 align="center"><u>Laporan Data Sapi</u></h4>
    <table>
      <thead>
       <tr>
        <th class="short">#</th>
        <th class="normal">Sapi</th>
        <th class="normal">Berat Awal</th>
        <th class="normal">Berat Akhir</th>
        <th class="normal">Deskripsi</th>
      </tr>
    </thead>
    <tbody>
     <?php $no=1;
     for ($i=0; $i < count($all); $i++) { ?>
      <tr>
       <td><?= $no++ ?></td>
       <td><?= $all[$i]->identitas ?></td>
       <td><?= $all[$i]->berat_sapi ?></td>
       <td><?= $all[$i]->berat_terakhir ?></td>
       <td><?= $all[$i]->deskripsi ?></td>
     </tr>
   <?php } ?>
 </tbody>
</table>
</div>
</body>
</html>