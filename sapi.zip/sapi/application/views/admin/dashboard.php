<div class="section__content section__content--p30">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<div class="overview-wrap">
					<h2 class="title-1">Beranda</h2>
				</div>
				<div class="row m-t-25">
					<div class="col-sm-6 col-lg-3">
                        <div class="overview-item overview-item--c1">
                            <div class="overview__inner">
                                <div class="overview-box clearfix">
                                    <div class="icon">
                                        <i class="zmdi zmdi-account-o"></i>
                                    </div><br><br>
                                    <div class="text">
                                        <h2><?php echo count($sapi); ?></h2>
                                        <span><strong>Jumlah Sapi Perah</strong></span>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-sm-6 col-lg-3">
                        <div class="overview-item overview-item--c2">
                            <div class="overview__inner">
                                <div class="overview-box clearfix">
                                    <div class="icon">
                                        <i class="zmdi zmdi-account-o"></i>
                                    </div><br><br>
                                    <div class="text">
                                        <h2><?php echo count($agen); ?></h2>
                                        <span><strong>Jumlah Agen</strong></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-sm-6 col-lg-3">
                        <div class="overview-item overview-item--c3">
                            <div class="overview__inner">
                                <div class="overview-box clearfix">
                                    <div class="icon">
                                        <i class="zmdi zmdi-account-o"></i>
                                    </div><br><br>
                                    <div class="text">
                                        <h2><?php echo count($pegawai); ?></h2>
                                        <span><strong>Jumlah Pegawai</strong></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-sm-6 col-lg-3">
                        <div class="overview-item overview-item--c4">
                            <div class="overview__inner">
                                <div class="overview-box clearfix">
                                    <div class="icon">
                                        <i class="zmdi zmdi-account-o"></i>
                                    </div>
                                    <div class="text">
                                        <h2><?php echo nominal($pengeluaran->total_pengeluaran); ?></h2>
                                        <span><strong>Total Pengeluaran</strong></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-lg-3">
                        <div class="overview-item overview-item--c1">
                            <div class="overview__inner">
                                <div class="overview-box clearfix">
                                    <div class="icon">
                                        <i class="zmdi zmdi-account-o"></i>
                                    </div><br><br>
                                    <div class="text">
                                        <h2><?php echo nominal($distribusi->total_distribusi); ?></h2>
                                        <span><strong>Total Distribusi</strong></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-lg-3">
                        <div class="overview-item overview-item--c2">
                            <div class="overview__inner">
                                <div class="overview-box clearfix">
                                    <div class="icon">
                                        <i class="zmdi zmdi-account-o"></i>
                                    </div><br><br><br>
                                    <div class="text">
                                        <h2><?php $stok=$susu->total_liter-$distribusi->jml_brg_keluar; echo ($stok); ?></h2>
                                        <span><strong>Stok valuation</strong></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-lg-3">
                        <div class="overview-item overview-item--c3">
                            <div class="overview__inner">
                                <div class="overview-box clearfix">
                                    <div class="icon">
                                        <i class="zmdi zmdi-account-o"></i>
                                    </div>
                                    <div class="text">
                                        <h2><?php
                                        $profit = $distribusi->total_distribusi-$pengeluaran->total_pengeluaran;
                                        if ($profit < 0){
                                         echo nominal((-round(($profit)/($stok),2)) + ($distribusi->hpp ));
                                     }else{
                                        echo nominal($distribusi->hpp);
                                    } ?>
                                </h2>
                                <span><strong>Harga Rekomendasi Per Liter</strong></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-lg-3">
                <div class="overview-item overview-item--c4">
                    <div class="overview__inner">
                        <div class="overview-box clearfix">
                            <div class="icon">
                                <i class="zmdi zmdi-account-o"></i>
                            </div><br><br>
                            <div class="text">
                                <h2><?php echo nominal($profit); ?></h2>
                                <span><strong> <?="Jumlah Profit"?>
                            </strong></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>
</div>
