<div class="col-md-12">

    <a href="<?= base_url()?>agen/add" type="button" class="btn btn-primary">Add</a>
    <!-- DATA TABLE-->
    <div class="table-responsive m-b-40">
        <table class="table table-borderless table-data3" id="example">
            <thead>
                <tr>
                    <th>No.</th>
                    <th>Kode Agen</th>
                    <th>Nama Agen</th>
                    <th>Alamat</th>
                    <th>Nomor Telepon</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no=1;
                for ($i=0; $i < count($all); $i++) { 
                    ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= $all[$i]->kode_agen ?></td>
                        <td><?= $all[$i]->nama_agen ?></td>
                        <td><?= $all[$i]->alamat_agen ?></td>
                        <td><?= $all[$i]->telepon_agen ?></td>
                        <td><a href="<?= base_url()?>agen/edit/<?= $all[$i]->id_agen ?>" type="button" class="btn btn-success">Edit</a> <a href="<?= base_url()?>agen/delete/<?=$all[$i]->id_agen?>" type="button" class="btn btn-danger">Delete</a></td>
                    </tr>
                <?php }?>
            </tbody>
        </table>
    </div>
    <!-- END DATA TABLE-->
</div>
