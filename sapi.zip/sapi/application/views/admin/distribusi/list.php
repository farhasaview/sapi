<div class="col-md-12">
    <a href="<?= base_url()?>distribusi/add" type="button" class="btn btn-primary">Add</a>
    <!-- DATA TABLE-->
    <div class="table-responsive m-b-40">
        <table class="table table-borderless table-data3" id="example">
            <thead>
                <tr>
                    <th>No.</th>
                    <th>Tanggal Distribusi</th>
                    <th>Agen Distributor</th>
                    <th>Kode Distribusi</th>
                    <th>Harga Satuan</th>
                    <th>Jumlah Liter</th>
                    <th>Total Uang</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no=1;
                for ($i=0; $i < count($all); $i++) { 
                    ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= $all[$i]->tgl_distribusi ?></td>
                        <td><?= $all[$i]->nama_agen ?></td>
                        <td><?= $all[$i]->kode_distribusi ?></td>
                        <td><?= $all[$i]->harga_satuan ?></td>
                        <td><?= $all[$i]->jumlah ?></td>
                        <td><?= $all[$i]->jumlah * $all[$i]->harga_satuan ?></td>
                        <td><a href="<?= base_url()?>distribusi/edit/<?= $all[$i]->id_distribusi ?>" type="button" class="btn btn-success">Edit</a> <a href="<?= base_url()?>distribusi/delete/<?=$all[$i]->id_distribusi?>" type="button" class="btn btn-danger">Delete</a></td>
                    </tr>
                <?php }?>
            </tbody>
        </table>
    </div>
    <!-- END DATA TABLE-->
</div>