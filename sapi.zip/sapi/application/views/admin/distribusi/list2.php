<div class="col-md-12">
  
  <!-- DATA TABLE-->
  <div class="table-responsive m-b-40">
    
    <form action="<?= base_url()?>distribusi/reportdistribusi" method="POST">
      <div class="form-row align-items-center">
        <div class="col-sm-3 my-1">
          <label class="sr-only" for="inlineFormInputName">Mulai</label>
          <input type="date" value="<?php echo set_value('date1')?>" name="date1" class="form-control">
        </div>
        <div class="col-sm-3 my-1">
          <label class="sr-only" for="inlineFormInputGroupUsername">Akhir</label>
          <div class="input-group">
            <div class="input-group-prepend">
             
            </div>
            <input type="date" name="date2" value="<?php echo set_value('date2')?>" class="form-control" id="inlineFormInputGroupUsername">
          </div>
        </div>
        <div class="col-auto my-1">
          <button type="submit" name="btn" value="submit" class="btn btn-primary">Submit</button>
        </div>
        <div class="col-auto my-1">
          <button type="submit" formtarget="_blank" name="btn" value="print" class="btn btn-primary">Print Per Periode</button>
        </div>
        <div class="col-auto my-1">
          <button type="submit" formtarget="_blank" name="btn" value="printall" class="btn btn-primary">Print All</button>
        </div>
      </div>
    </form>



    <table class="table table-borderless table-data3">
      <thead>
        <tr>
          <th>#</th>
          <th>Tanggal Distribusi</th>
          <th>Agen Distributor</th>
          <th>Kode Distribusi</th>
          <th>Harga Satuan</th>
          <th>Jumlah</th>
          <th>Total</th>
        </tr>
      </thead>
      <tbody>
        <?php $no=1;
        foreach ($all as $data) { 
          ?>
          <tr>
            <td><?= $no++ ?></td>
            <td><?= $data['tgl_distribusi'] ?></td>
            <td><?= $data['nama_agen'] ?></td>
            <td><?= $data['kode_distribusi'] ?></td>
            <td><?= $data['harga_satuan'] ?></td>
            <td><?= $data['jumlah'] ?></td>
            <td><?= $data['jumlah'] * $data['harga_satuan'] ?></td> 
          </tr>
        <?php }?>
      </tbody>
    </table>
  </div>
  <!-- END DATA TABLE-->
</div>