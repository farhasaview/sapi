<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<!-- Jquery JS-->
<script src="<?= base_url()?>assets/vendor/jquery-3.2.1.min.js"></script>
<!-- Bootstrap JS-->
<script src="<?= base_url()?>assets/vendor/bootstrap-4.1/popper.min.js"></script>
<script src="<?= base_url()?>assets/vendor/bootstrap-4.1/bootstrap.min.js"></script>
<!-- Vendor JS       -->
<script src="<?= base_url()?>assets/vendor/slick/slick.min.js">
</script>
<script src="<?= base_url()?>assets/vendor/wow/wow.min.js"></script>
<script src="<?= base_url()?>assets/vendor/animsition/animsition.min.js"></script>
<script src="<?= base_url()?>assets/vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
</script>
<script src="<?= base_url()?>assets/vendor/counter-up/jquery.waypoints.min.js"></script>
<script src="<?= base_url()?>assets/vendor/counter-up/jquery.counterup.min.js">
</script>
<script src="<?= base_url()?>assets/vendor/circle-progress/circle-progress.min.js"></script>
<script src="<?= base_url()?>assets/vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
<script src="<?= base_url()?>assets/vendor/chartjs/Chart.bundle.min.js"></script>
<script src="<?= base_url()?>assets/vendor/select2/select2.min.js">

</script>
<!-- <script src='https://code.jquery.com/jquery-1.12.3.js'></script> -->
<script src='<?= base_url()?>assets/vendor/jquery.dataTables.min.js'></script>
<script src='<?= base_url()?>assets/vendor/dataTables.bootstrap4.min.js'></script>

<script src="<?= base_url()?>assets/js/main.js"></script>
<script type="text/javascript">
    var ypoints;
    var points;
    $(document).ready(function(){
        $('#example').DataTable();
        
        var format = function(num){
            var str = num.toString().replace("$", ""), parts = false, output = [], i = 1, formatted = null;
            if(str.indexOf(".") > 0) {
                parts = str.split(".");
                str = parts[0];
            }
            str = str.split("").reverse();
            for(var j = 0, len = str.length; j < len; j++) {
                if(str[j] != ",") {
                    output.push(str[j]);
                    if(i%3 == 0 && j < (len - 1)) {
                        output.push(",");
                    }
                    i++;
                }
            }
            formatted = output.reverse().join("");
            return("Rp. " + formatted + ((parts) ? "." + parts[1].substr(0, 2) : ""));
        };
        $(function(){
            $("#currency").keyup(function(e){
                $(this).val(format($(this).val()));
            });
        });

        console.log('aaa');
        $('#jml').keyup(function(){
          ypoints = parseInt($('#harga').val());        
          points = parseInt($(this).val());

          console.log("Points: "+(format(points*ypoints)));
          $('#total').val(format(points*ypoints));
      });
    });
</script>
<body>
    <center><i> <a href="<?= base_url()?>welcome"> Copyright&copy; Brotherhood 2018 All Right Reserved </i></center>
    </body>
    </html>