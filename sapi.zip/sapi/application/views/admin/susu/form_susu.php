<div class="section__content section__content--p30">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-6">

                <div class="card">
                    <div class="card-header">Form Susu</div>
                    <div class="card-body">
                        <div class="card-title">
                            <h3 class="text-center title-2"><?php echo $title ?></h3>
                        </div>
                        <hr>
                        <form action="<?= base_url()?>susu/save" method="post">
                            <div class="form-group">
                                <label for="cc-payment" class="control-label mb-1">Silahkan Pilih Sapi Perah yang mana</label>
                                <select name="id_sapi" id="SelectLm" class="form-control" required="true">
                                    <option value="">Please select</option>
                                    <!-- relasi susu ke sapi -->
                                    <?php for ($i=0; $i < count($sapi) ; $i++) { 
                                        ?>
                                        <option value="<?=$sapi[$i]->id_sapi?>" <?= $sapi[$i]->id_sapi==$susu['id_sapi'] ? 'Selected' : '' ?>><?=$sapi[$i]->identitas?></option>
                                    <?php } ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="cc-payment" class="control-label mb-1">Silahkan Pilih Pegawai yang memerah susu</label>
                                <select name="id_pegawai" id="SelectLm" class="form-control" required="true">
                                    <option value="">Please select</option>
                                    <!-- relasi susu ke pegawai -->
                                    <?php for ($i=0; $i < count($pegawai) ; $i++) { 
                                        ?>
                                        <option value="<?=$pegawai[$i]->id_pegawai?>" <?= $pegawai[$i]->id_pegawai==$susu['id_pegawai'] ? 'Selected' : '' ?>><?=$pegawai[$i]->nama_pegawai?></option>
                                    <?php } ?>
                                </select>
                            </div>   
                            <div class="form-group">
                                <label for="cc-payment" class="control-label mb-1">Tanggal Perah</label>
                                <input id="cc-pament" name="tgl_perah" type="date" class="form-control" value="<?= $susu['tgl_perah'] ?>">

                                <input type="hidden" name="id_susu" value="<?= $susu['id_susu'] ?>">
                                
                            </div>
                            <div class="form-group has-success">
                                <label for="cc-name" class="control-label mb-1">Jumlah Liter</label>
                                <input id="cc-name" name="jumlah_liter" value="<?= $susu['jumlah_liter'] ?>" type="number" class="form-control cc-name valid" data-val="true" data-val-required="Please enter the name on card"
                                autocomplete="cc-name" aria-required="true" aria-invalid="false" aria-describedby="cc-name-error" required="true">
                                <span class="help-block field-validation-valid" data-valmsg-for="cc-name" data-valmsg-replace="true"></span>
                            </div>                        
                        </div>
                        <div>
                            <button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">
                                <i class="fa fa-save fa-lg"></i>&nbsp;
                                <span id="payment-button-amount">Save</span>
                                <span id="payment-button-sending" style="display:none;">Sending…</span>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</div>