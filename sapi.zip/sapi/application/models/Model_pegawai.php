<?php

/*
* To change this template, choose Tools | Templates
* and open the template in the editor.
*/

class Model_pegawai extends CI_Model {

  function __construct() {
    parent::__construct();
  }

  public function all() {
    $sql = "SELECT * FROM tbl_pegawai";
    $query = $this->db->query($sql);
    $result = $query->result();
    return $result;
    $query->free_result();
  }

  public function find($id) {
    $sql = "SELECT * FROM tbl_pegawai WHERE id_pegawai=?";
    $query = $this->db->query($sql, array($id));
    if ($query->num_rows() > 0) {
      $result = $query->result();
      return $result[0];
    } else {
      return null;
    }
    $query->free_result();
  }

  public function add($param) {
    $sql = "INSERT INTO tbl_pegawai (nama_pegawai, alamat, telepon) VALUES (?,?,?)";
    $this->db->query($sql, array($param['nama_pegawai'], $param['alamat'], $param['telepon'] ));
    return true;
  }

  public function edit($param) {
   
      $sql = "UPDATE tbl_pegawai SET nama_pegawai=?, alamat=?, telepon=? WHERE id_pegawai=?";
      $this->db->query($sql, array($param['nama_pegawai'], $param['alamat'], $param['telepon'], $param['id_pegawai']));
    return true;
  }

  public function delete($id) {
    $sql = "DELETE FROM tbl_pegawai WHERE id_pegawai = ?";
    $this->db->query($sql, array($id));
    return true;
  }

}