<?php

/*
(controller) Agen->(Model)Model_agen->(view) admin/agen/.
*/

class Model_agen extends CI_Model {

  function __construct() {
    parent::__construct();
  }

  public function all() {
    $sql = "SELECT * FROM tbl_agen";
    $query = $this->db->query($sql);
    $result = $query->result();
    return $result;
    $query->free_result();
  }

  public function find($id) {
    $sql = "SELECT * FROM tbl_agen WHERE id_agen=?";
    $query = $this->db->query($sql, array($id));
    if ($query->num_rows() > 0) {
      $result = $query->result();
      return $result[0];
    } else {
      return null;
    }
    $query->free_result();
  }

  public function add($param) {
    $sql = "INSERT INTO tbl_agen (kode_agen, nama_agen, alamat_agen, telepon_agen) VALUES (?, ?, ?, ?)";
    $this->db->query($sql, array($param['kode_agen'], $param['nama_agen'], $param['alamat_agen'], $param['telepon_agen'] ));
    return true;
  }

  public function edit($param) {
   
      $sql = "UPDATE tbl_agen SET kode_agen=?, nama_agen=?, alamat_agen=?, telepon_agen=? WHERE id_agen=?";
      $this->db->query($sql, array($param['kode_agen'], $param['nama_agen'], $param['alamat_agen'], $param['telepon_agen'], $param['id_agen']));
   
    return true;
  }

  public function delete($id) {
    $sql = "DELETE FROM tbl_agen WHERE id_agen = ?";
    $this->db->query($sql, array($id));
    return true;
  }

}