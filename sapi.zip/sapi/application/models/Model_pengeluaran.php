<?php

/*
* To change this template, choose Tools | Templates
* and open the template in the editor.
*/

class Model_pengeluaran extends CI_Model {

  function __construct() {
    parent::__construct();
  }

  public function all() {
    $sql = "SELECT * FROM tbl_pengeluaran";
    $query = $this->db->query($sql);
    $result = $query->result();
    return $result;
    $query->free_result();
  }

  public function find($id) {
    $sql = "SELECT * FROM tbl_pengeluaran WHERE id_pengeluaran=?";
    $query = $this->db->query($sql, array($id));
    if ($query->num_rows() > 0) {
      $result = $query->result();
      return $result[0];
    } else {
      return null;
    }
    $query->free_result();
  }

  public function add($param) {
    $sql = "INSERT INTO tbl_pengeluaran (nama_pengeluaran, tgl_pengeluaran, jml_pengeluaran) VALUES (?, ?, ?)";
    $this->db->query($sql, array($param['nama_pengeluaran'], $param['tgl_pengeluaran'], $param['jml_pengeluaran'] ));
    return true;
  }

  public function edit($param) {
   
      $sql = "UPDATE tbl_pengeluaran SET nama_pengeluaran=?, tgl_pengeluaran=?, jml_pengeluaran=? WHERE id_pengeluaran=?";
      $this->db->query($sql, array($param['nama_pengeluaran'], $param['tgl_pengeluaran'], $param['jml_pengeluaran'], $param['id_pengeluaran']));
    return true;
  }

  public function delete($id) {
    $sql = "DELETE FROM tbl_pengeluaran WHERE id_pengeluaran = ?";
    $this->db->query($sql, array($id));
    return true;
  }

  public function total_pengeluaran() {
    $sql = "SELECT SUM(jml_pengeluaran) as total_pengeluaran FROM tbl_pengeluaran";
    $query = $this->db->query($sql);
    if ($query->num_rows() > 0) {
      $result = $query->result();
      return $result[0];
    } else {
      return null;
    }
    $query->free_result();
  }

}

