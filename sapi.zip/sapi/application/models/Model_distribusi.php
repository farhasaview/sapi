<?php

/*
(controller) distribusi->(Model)Model_distribusi->(view) admin/distribusi/.
*/

class Model_distribusi extends CI_Model {

  function __construct() {
    parent::__construct();
  }

  public function all() {
    $sql = "SELECT a.*,b.* FROM tbl_distribusi as a, tbl_agen as b where a.id_agen=b.id_agen";
    $query = $this->db->query($sql);
    $result = $query->result();
    return $result;
    $query->free_result();
  }

  public function find($id) {
    $sql = "SELECT * FROM tbl_distribusi WHERE id_distribusi=?";
    $query = $this->db->query($sql, array($id));
    if ($query->num_rows() > 0) {
      $result = $query->result();
      return $result[0];
    } else {
      return null;
    }
    $query->free_result();
  }

  public function add($param) {
    $sql = "INSERT INTO tbl_distribusi (kode_distribusi, tgl_distribusi, harga_satuan, id_agen, jumlah) VALUES (?, ?, ?, ?, ?)";
    $this->db->query($sql, array($param['kode_distribusi'], $param['tgl_distribusi'], $param['harga_satuan'], $param['id_agen'], $param['jumlah'] ));
    return true;
  }

  public function edit($param) {
   
      $sql = "UPDATE tbl_distribusi SET kode_distribusi=?, tgl_distribusi=?, harga_satuan=?, id_agen=?, jumlah=? WHERE id_distribusi=?";
      $this->db->query($sql, array($param['kode_distribusi'], $param['tgl_distribusi'], $param['harga_satuan'], $param['id_agen'], $param['jumlah'], $param['id_distribusi']));
   
    return true;
  }

  public function delete($id) {
    $sql = "DELETE FROM tbl_distribusi WHERE id_distribusi = ?";
    $this->db->query($sql, array($id));
    return true;
  }

   public function total_distribusi() {
    $sql = "SELECT SUM(jumlah * harga_satuan) as total_distribusi, SUM(jumlah) as jml_brg_keluar, SUM(harga_satuan) / count(harga_satuan) as hpp FROM tbl_distribusi";
    $query = $this->db->query($sql);
    if ($query->num_rows() > 0) {
      $result = $query->result();
      return $result[0];
    } else {
      return null;
    }
    $query->free_result();
  }

}