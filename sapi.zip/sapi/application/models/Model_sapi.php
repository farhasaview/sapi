<?php

/*
* To change this template, choose Tools | Templates
* and open the template in the editor.
*/

class Model_sapi extends CI_Model {

  function __construct() {
    parent::__construct();
  }

  public function all() {
    $sql = "SELECT * FROM tbl_sapi";
    $query = $this->db->query($sql);
    $result = $query->result();
    return $result;
    $query->free_result();
  }

  public function find($id) {
    $sql = "SELECT * FROM tbl_sapi WHERE id_sapi=?";
    $query = $this->db->query($sql, array($id));
    if ($query->num_rows() > 0) {
      $result = $query->result();
      return $result[0];
    } else {
      return null;
    }
    $query->free_result();
  }

  public function add($param) {
    $sql = "INSERT INTO tbl_sapi (identitas, berat_sapi, berat_terakhir, deskripsi) VALUES (?, ?, ?, ?)";
    $this->db->query($sql, array($param['identitas'], $param['berat_sapi'], $param['berat_terakhir'], $param['deskripsi'] ));
    return true;
  }

  public function edit($param) {
   
      $sql = "UPDATE tbl_sapi SET identitas=?, berat_sapi=?, berat_terakhir=?, deskripsi=? WHERE id_sapi=?";
      $this->db->query($sql, array($param['identitas'], $param['berat_sapi'], $param['berat_terakhir'], $param['deskripsi'], $param['id_sapi']));
   
    return true;
  }

  public function delete($id) {
    $sql = "DELETE FROM tbl_sapi WHERE id_sapi = ?";
    $this->db->query($sql, array($id));
    return true;
  }

}

