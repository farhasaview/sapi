<?php

/*
* To change this template, choose Tools | Templates
* and open the template in the editor.
*/

class Model_susu extends CI_Model {

  function __construct() {
    parent::__construct();
  }

  public function all() {
    $sql = "SELECT a.*,b.*,c.* FROM tbl_susu as a, tbl_sapi as b, tbl_pegawai as c where a.id_sapi=b.id_sapi and a.id_pegawai=c.id_pegawai";
    $query = $this->db->query($sql);
    $result = $query->result();
    return $result;
    $query->free_result();
  }

  public function find($id) {
    $sql = "SELECT * FROM tbl_susu WHERE id_susu=?";
    $query = $this->db->query($sql, array($id));
    if ($query->num_rows() > 0) {
      $result = $query->result();
      return $result[0];
    } else {
      return null;
    }
    $query->free_result();
  }

  public function add($param) {
    $sql = "INSERT INTO tbl_susu (tgl_perah, jumlah_liter, id_sapi, id_pegawai) VALUES (?, ?, ?, ?)";
    $this->db->query($sql, array($param['tgl_perah'], $param['jumlah_liter'], $param['id_sapi'], $param['id_pegawai'] ));
    return true;
  }

  public function edit($param) {
   
      $sql = "UPDATE tbl_susu SET tgl_perah=?, jumlah_liter=?, id_sapi=?, id_pegawai=? WHERE id_susu=?";
      $this->db->query($sql, array($param['tgl_perah'], $param['jumlah_liter'], $param['id_sapi'], $param['id_pegawai'], $param['id_susu']));
   
    return true;
  }

  public function delete($id) {
    $sql = "DELETE FROM tbl_susu WHERE id_susu = ?";
    $this->db->query($sql, array($id));
    return true;
  }

  public function total_liter() {
    $sql = "SELECT SUM(jumlah_liter) as total_liter FROM tbl_susu";
    $query = $this->db->query($sql);
    if ($query->num_rows() > 0) {
      $result = $query->result();
      return $result[0];
    } else {
      return null;
    }
    $query->free_result();
  }

}

